/**
 * Checks the client cookie for a specific name. Returns the value if
 * found, otherwise undefined. Does not do any encoding or decoding.
 */
export declare function getClientCookie(name: string): string | undefined;
/**
 * Sets a client cookie with the specified name and value. The cookie
 * is set to expire in one year and is accessible to all paths on the
 * domain. The SameSite attribute is set to Lax. Does not do any
 * encoding or decoding.
 */
export declare function setClientCookie(name: string, value: string): void;
//# sourceMappingURL=cookies.d.ts.map