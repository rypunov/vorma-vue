// kit/_typescript/cookies/cookies.ts
function getClientCookie(name) {
  const match = document.cookie.match(new RegExp(`(^| )${name}=([^;]*)`));
  return match ? match[2] : void 0;
}
function setClientCookie(name, value) {
  document.cookie = `${name}=${value}; path=/; max-age=31536000; SameSite=Lax`;
}
export {
  getClientCookie,
  setClientCookie
};
//# sourceMappingURL=cookies.js.map
