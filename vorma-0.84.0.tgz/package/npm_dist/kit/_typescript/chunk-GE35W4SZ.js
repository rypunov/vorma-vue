// kit/_typescript/matcher/parse_segments.ts
function parseSegments(path) {
  if (path === "" || path === "/") {
    return path === "/" ? [""] : [];
  }
  const startIdx = path.startsWith("/") ? 1 : 0;
  const segments = [];
  let start = startIdx;
  for (let i = startIdx; i < path.length; i++) {
    if (path[i] === "/") {
      if (i > start) {
        segments.push(path.substring(start, i));
      }
      start = i + 1;
    }
  }
  if (start < path.length) {
    segments.push(path.substring(start));
  }
  if (path.endsWith("/")) {
    segments.push("");
  }
  return segments;
}

// kit/_typescript/matcher/register.ts
var NODE_STATIC = 0;
var NODE_DYNAMIC = 1;
var NODE_SPLAT = 2;
var SCORE_STATIC_MATCH = 2;
var SCORE_DYNAMIC = 1;
var SEG_TYPES = {
  splat: "splat",
  static: "static",
  dynamic: "dynamic",
  index: "index"
};
function createSegmentNode() {
  return {
    pattern: "",
    nodeType: NODE_STATIC,
    children: null,
    dynChildren: [],
    paramName: "",
    finalScore: 0
  };
}
function findOrCreateChild(node, segment) {
  if (segment === "*" || segment.length > 0 && segment[0] === ":") {
    for (const child2 of node.dynChildren) {
      if (child2.paramName === segment.substring(1)) return child2;
    }
    return addDynamicChild(node, segment);
  }
  if (node.children === null) node.children = /* @__PURE__ */ new Map();
  let child = node.children.get(segment);
  if (child) return child;
  child = createSegmentNode();
  child.nodeType = NODE_STATIC;
  node.children.set(segment, child);
  return child;
}
function addDynamicChild(node, segment) {
  const child = createSegmentNode();
  if (segment === "*") {
    child.nodeType = NODE_SPLAT;
  } else {
    child.nodeType = NODE_DYNAMIC;
    child.paramName = segment.substring(1);
  }
  node.dynChildren.push(child);
  return child;
}
function getSegmentType(segment, dynamicPrefix, splatRune) {
  if (segment === "") return SEG_TYPES.index;
  if (segment.length === 1 && segment === splatRune) return SEG_TYPES.splat;
  if (segment.length > 0 && segment[0] === dynamicPrefix)
    return SEG_TYPES.dynamic;
  return SEG_TYPES.static;
}
function isStatic(segments) {
  for (const segment of segments) {
    if (segment.segType === SEG_TYPES.splat || segment.segType === SEG_TYPES.dynamic) {
      return false;
    }
  }
  return true;
}
function normalizePattern(originalPattern, config) {
  let normalizedPattern = originalPattern;
  if (config.usingExplicitIndexSegment) {
    if (normalizedPattern.endsWith("/")) {
      if (normalizedPattern !== "/") {
        throw new Error(`bad trailing slash: ${originalPattern}`);
      }
      normalizedPattern = normalizedPattern.replace(/\/+$/, "");
    }
    if (normalizedPattern.endsWith(config.slashIndexSegment)) {
      normalizedPattern = normalizedPattern.slice(
        0,
        -config.explicitIndexSegment.length
      );
    }
  }
  const rawSegments = parseSegments(normalizedPattern);
  const segments = [];
  let numberOfDynamicParamSegs = 0;
  for (const seg of rawSegments) {
    let normalizedVal = seg;
    const segType = getSegmentType(
      seg,
      config.dynamicParamPrefixRune,
      config.splatSegmentRune
    );
    if (segType === SEG_TYPES.dynamic) {
      numberOfDynamicParamSegs++;
      normalizedVal = ":" + seg.substring(1);
    }
    if (segType === SEG_TYPES.splat) {
      normalizedVal = "*";
    }
    segments.push({ normalizedVal, segType });
  }
  const segLen = segments.length;
  let lastType = segLen > 0 ? segments[segLen - 1].segType : SEG_TYPES.static;
  let finalNormalizedPattern = "/";
  for (let i = 0; i < segments.length; i++) {
    finalNormalizedPattern += segments[i].normalizedVal;
    if (i < segLen - 1) finalNormalizedPattern += "/";
  }
  if (finalNormalizedPattern.endsWith("/") && lastType !== SEG_TYPES.index) {
    finalNormalizedPattern = finalNormalizedPattern.replace(/\/+$/, "");
  }
  return {
    originalPattern,
    normalizedPattern: finalNormalizedPattern,
    normalizedSegments: segments,
    lastSegType: lastType,
    lastSegIsNonRootSplat: lastType === SEG_TYPES.splat && segLen > 1,
    lastSegIsIndex: lastType === SEG_TYPES.index,
    numberOfDynamicParamSegs
  };
}
function createPatternRegistry(opts) {
  const config = {
    dynamicParamPrefixRune: opts?.dynamicParamPrefixRune ?? ":",
    splatSegmentRune: opts?.splatSegmentRune ?? "*",
    explicitIndexSegment: opts?.explicitIndexSegment ?? "",
    slashIndexSegment: "/" + (opts?.explicitIndexSegment ?? ""),
    usingExplicitIndexSegment: (opts?.explicitIndexSegment ?? "") !== ""
  };
  if (config.explicitIndexSegment.includes("/")) {
    throw new Error("explicit index segment cannot contain /");
  }
  return {
    staticPatterns: /* @__PURE__ */ new Map(),
    dynamicPatterns: /* @__PURE__ */ new Map(),
    rootNode: createSegmentNode(),
    config
  };
}
function registerPattern(registry, originalPattern) {
  const normalized = normalizePattern(originalPattern, registry.config);
  if (!(globalThis.window && globalThis.document) && (registry.staticPatterns.has(normalized.normalizedPattern) || registry.dynamicPatterns.has(normalized.normalizedPattern))) {
    console.warn(`already registered: ${originalPattern}`);
  }
  if (isStatic(normalized.normalizedSegments)) {
    registry.staticPatterns.set(normalized.normalizedPattern, normalized);
    return normalized;
  }
  registry.dynamicPatterns.set(normalized.normalizedPattern, normalized);
  let current = registry.rootNode;
  let nodeScore = 0;
  for (let i = 0; i < normalized.normalizedSegments.length; i++) {
    const segment = normalized.normalizedSegments[i];
    const child = findOrCreateChild(current, segment.normalizedVal);
    if (segment.segType === SEG_TYPES.dynamic) {
      nodeScore += SCORE_DYNAMIC;
    } else if (segment.segType !== SEG_TYPES.splat) {
      nodeScore += SCORE_STATIC_MATCH;
    }
    if (i === normalized.normalizedSegments.length - 1) {
      child.finalScore = nodeScore;
      child.pattern = normalized.normalizedPattern;
    }
    current = child;
  }
  return normalized;
}

export {
  parseSegments,
  NODE_STATIC,
  NODE_DYNAMIC,
  NODE_SPLAT,
  SCORE_STATIC_MATCH,
  SCORE_DYNAMIC,
  SEG_TYPES,
  createPatternRegistry,
  registerPattern
};
//# sourceMappingURL=chunk-GE35W4SZ.js.map
