// kit/_typescript/converters/converters.ts
function bytesToUTF8(bytes) {
  return new TextDecoder().decode(bytes);
}
function bytesToHex(bytes) {
  return Array.from(bytes, (x) => x.toString(16).padStart(2, "0")).join("");
}
function bytesToBase64(bytes) {
  const callback = (x) => String.fromCodePoint(x);
  return btoa(Array.from(bytes, callback).join(""));
}
function bytesToBase64URL(bytes) {
  const base64 = bytesToBase64(bytes);
  return base64ToBase64URL(base64);
}
function utf8ToBytes(utf8) {
  return new TextEncoder().encode(utf8);
}
function utf8ToHex(utf8) {
  const bytes = utf8ToBytes(utf8);
  return bytesToHex(bytes);
}
function utf8ToBase64(utf8) {
  const bytes = utf8ToBytes(utf8);
  return bytesToBase64(bytes);
}
function utf8ToBase64URL(utf8) {
  const bytes = utf8ToBytes(utf8);
  return bytesToBase64URL(bytes);
}
function hexToBytes(hex) {
  const cleanHex = hex.startsWith("0x") ? hex.slice(2) : hex;
  const bytes = cleanHex.match(/.{1,2}/g)?.map((byte) => Number.parseInt(byte, 16)) || [];
  return new Uint8Array(bytes);
}
function hexToUTF8(hex) {
  const bytes = hexToBytes(hex);
  return bytesToUTF8(bytes);
}
function hexToBase64(hex) {
  const bytes = hexToBytes(hex);
  return bytesToBase64(bytes);
}
function hexToBase64URL(hex) {
  const bytes = hexToBytes(hex);
  return bytesToBase64URL(bytes);
}
function base64ToBytes(base64) {
  return Uint8Array.from(atob(base64), (m) => m.codePointAt(0) || 0);
}
function base64ToUTF8(base64) {
  const bytes = base64ToBytes(base64);
  return bytesToUTF8(bytes);
}
function base64ToHex(base64) {
  const bytes = base64ToBytes(base64);
  return bytesToHex(bytes);
}
function base64ToBase64URL(base64) {
  return base64.replace(/[\r\n\t ]+/g, "").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function base64URLToBytes(base64URL) {
  const base64 = base64URLToBase64(base64URL);
  return base64ToBytes(base64);
}
function base64URLToUTF8(base64URL) {
  const bytes = base64URLToBytes(base64URL);
  return bytesToUTF8(bytes);
}
function base64URLToHex(base64URL) {
  const bytes = base64URLToBytes(base64URL);
  return bytesToHex(bytes);
}
function base64URLToBase64(base64URL) {
  return base64URL.padEnd(base64URL.length + (4 - base64URL.length % 4) % 4, "=").replace(/-/g, "+").replace(/_/g, "/");
}
export {
  base64ToBase64URL,
  base64ToBytes,
  base64ToHex,
  base64ToUTF8,
  base64URLToBase64,
  base64URLToBytes,
  base64URLToHex,
  base64URLToUTF8,
  bytesToBase64,
  bytesToBase64URL,
  bytesToHex,
  bytesToUTF8,
  hexToBase64,
  hexToBase64URL,
  hexToBytes,
  hexToUTF8,
  utf8ToBase64,
  utf8ToBase64URL,
  utf8ToBytes,
  utf8ToHex
};
//# sourceMappingURL=converters.js.map
