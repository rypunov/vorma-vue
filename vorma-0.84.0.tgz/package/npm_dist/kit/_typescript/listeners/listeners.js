// kit/_typescript/listeners/listeners.ts
import { debounce } from "vorma/kit/debounce";
function addOnWindowFocusListener(callback) {
  const debouncedCallback = debounce(callback, 30);
  const ifVisibleCallback = () => {
    if (document.visibilityState === "visible") {
      debouncedCallback();
    }
  };
  window.addEventListener("focus", debouncedCallback);
  window.addEventListener("visibilitychange", ifVisibleCallback);
  return () => {
    window.removeEventListener("focus", debouncedCallback);
    window.removeEventListener("visibilitychange", ifVisibleCallback);
  };
}
export {
  addOnWindowFocusListener
};
//# sourceMappingURL=listeners.js.map
