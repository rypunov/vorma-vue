export declare function addOnWindowFocusListener(callback: () => void): () => void;
//# sourceMappingURL=listeners.d.ts.map