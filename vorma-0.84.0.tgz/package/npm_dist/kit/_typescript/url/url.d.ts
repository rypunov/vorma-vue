export declare function getIsErrorRes(response: Response): boolean;
export declare function getIsGETRequest(requestInit?: RequestInit): boolean;
export declare function getAnchorDetailsFromEvent(event: MouseEvent): {
    anchor: HTMLAnchorElement;
    isEligibleForDefaultPrevention: boolean;
    isInternal: boolean;
} | null;
export type HrefDetails = {
    url: URL;
    isHTTP: true;
    absoluteURL: string;
    relativeURL: string;
    isExternal: boolean;
    isInternal: boolean;
} | {
    isHTTP: false;
};
export declare function getHrefDetails(href: string): HrefDetails;
export declare function getPrefetchHandlers(href: string, timeout?: number): {
    start(): void;
    stop(): void;
    url: URL;
    isHTTP: true;
    absoluteURL: string;
    relativeURL: string;
    isExternal: boolean;
    isInternal: boolean;
} | undefined;
export declare function prefetch(relativeURL: string): void;
//# sourceMappingURL=url.d.ts.map