// kit/_typescript/url/url.ts
function getIsErrorRes(response) {
  return String(response.status).startsWith("4") || String(response.status).startsWith("5");
}
function getIsGETRequest(requestInit) {
  return !requestInit?.method || requestInit.method.toLowerCase() === "get" || requestInit.method.toLowerCase() === "head";
}
function getAnchorDetailsFromEvent(event) {
  if (!event || !event.target || !event.target.closest) {
    return null;
  }
  const anchor = event.target.closest("a");
  if (!anchor) {
    return null;
  }
  const isEligibleForDefaultPrevention = anchor.target !== "_blank" && // ignore new tabs
  event.button !== 1 && // middle mouse button click
  !anchor.href.startsWith("#") && // ignore hash links
  !anchor.hasAttribute("download") && // ignore downloads
  !event.ctrlKey && // ignore ctrl+click
  !event.shiftKey && // ignore shift+click
  !event.metaKey && // ignore cmd+click
  !event.altKey;
  const hrefDetails = getHrefDetails(anchor.href);
  const isInternal = hrefDetails.isHTTP && hrefDetails.isInternal;
  return { anchor, isEligibleForDefaultPrevention, isInternal };
}
function getHrefDetails(href) {
  if (!href) {
    return { isHTTP: false };
  }
  let url;
  try {
    url = new URL(href, window.location.href);
  } catch {
    return { isHTTP: false };
  }
  const isExternal = url.origin !== window.location.origin;
  const isInternal = !isExternal;
  const isHTTP = url.protocol.startsWith("http");
  if (!isHTTP) {
    return { isHTTP: false };
  }
  if (isExternal) {
    return {
      url,
      isHTTP: true,
      absoluteURL: url.href,
      relativeURL: "",
      isExternal,
      isInternal
    };
  }
  return {
    url,
    isHTTP: true,
    absoluteURL: url.href,
    relativeURL: url.href.replace(url.origin, ""),
    isExternal,
    isInternal
  };
}
function getPrefetchHandlers(href, timeout = 50) {
  const hrefDetails = getHrefDetails(href);
  if (!hrefDetails.isHTTP) {
    return;
  }
  const { relativeURL, isExternal } = hrefDetails;
  if (!relativeURL || isExternal) {
    return;
  }
  let timer;
  return {
    ...hrefDetails,
    start() {
      timer = window.setTimeout(() => prefetch(relativeURL), timeout);
    },
    stop() {
      document.querySelector(`link[href="${relativeURL}"]`)?.remove();
      clearTimeout(timer);
    }
  };
}
function prefetch(relativeURL) {
  document.querySelector(`link[href="${relativeURL}"]`)?.remove();
  const link = document.createElement("link");
  link.rel = "prefetch";
  link.href = relativeURL;
  link.id = relativeURL;
  document.head.appendChild(link);
}
export {
  getAnchorDetailsFromEvent,
  getHrefDetails,
  getIsErrorRes,
  getIsGETRequest,
  getPrefetchHandlers,
  prefetch
};
//# sourceMappingURL=url.js.map
