/**
 * Deterministically serializes a JSON-compatible value to a stable string.
 * Throws if it detects a circular reference. Does not support Maps, Sets,
 * Functions, or other non-JSON types.
 */
export declare function jsonStringifyStable(input: unknown): string;
//# sourceMappingURL=stringify_stable.d.ts.map