export declare function serializeToSearchParams(obj: Record<any, any>): URLSearchParams;
//# sourceMappingURL=search_param_serializer.d.ts.map