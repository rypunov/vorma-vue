// kit/_typescript/json/deep_equals.ts
function jsonDeepEquals(a, b) {
  if (a === b) {
    return true;
  }
  if (a == null || b == null) {
    return false;
  }
  if (typeof a !== typeof b) {
    return false;
  }
  const aIsArray = Array.isArray(a);
  const bIsArray = Array.isArray(b);
  if (aIsArray !== bIsArray) {
    return false;
  }
  if (aIsArray && bIsArray) {
    if (a.length !== b.length) {
      return false;
    }
    return a.every((item, index) => jsonDeepEquals(item, b[index]));
  }
  if (typeof a === "object" && typeof b === "object") {
    const aKeys = Object.keys(a);
    const bKeys = Object.keys(b);
    if (aKeys.length !== bKeys.length) {
      return false;
    }
    return aKeys.every((key) => {
      return Object.hasOwn(b, key) && jsonDeepEquals(a[key], b[key]);
    });
  }
  return false;
}

// kit/_typescript/json/search_param_serializer.ts
function serializeToSearchParams(obj) {
  const params = new URLSearchParams();
  function appendValue(key, value) {
    if (value === null || value === void 0) {
      params.append(key, "");
      return;
    }
    if (Array.isArray(value)) {
      if (value.length === 0) {
        params.append(key, "");
      } else {
        for (const item of value) {
          appendValue(key, item);
        }
      }
      return;
    }
    if (typeof value === "object") {
      const entries = Object.entries(value);
      if (entries.length === 0) {
        params.append(key, "");
      } else {
        entries.sort(([keyA], [keyB]) => keyA.localeCompare(keyB));
        for (const [subKey, subValue] of entries) {
          const newKey = key ? `${key}.${subKey}` : subKey;
          appendValue(newKey, subValue);
        }
      }
      return;
    }
    params.append(key, String(value));
  }
  if (typeof obj === "object" && obj !== null) {
    const entries = Object.entries(obj);
    entries.sort(([keyA], [keyB]) => keyA.localeCompare(keyB));
    for (const [key, value] of entries) {
      appendValue(key, value);
    }
  }
  return params;
}

// kit/_typescript/json/stringify_stable.ts
function jsonStringifyStable(input) {
  const stabilized = stabilizeStructure(input, /* @__PURE__ */ new WeakSet());
  return JSON.stringify(stabilized);
}
function stabilizeStructure(value, visited) {
  if (value === null || typeof value !== "object") {
    return value;
  }
  if (visited.has(value)) {
    throw new Error("Circular reference detected during stable JSON stringification");
  }
  visited.add(value);
  if (Array.isArray(value)) {
    const result = value.map((item) => stabilizeStructure(item, visited));
    visited.delete(value);
    return result;
  }
  const keys = Object.keys(value).sort();
  const stable = {};
  for (const key of keys) {
    stable[key] = stabilizeStructure(value[key], visited);
  }
  visited.delete(value);
  return stable;
}
export {
  jsonDeepEquals,
  jsonStringifyStable,
  serializeToSearchParams
};
//# sourceMappingURL=json.js.map
