/**
 * Performs a deep equality comparison of two JSON-compatible values.
 * Handles null, undefined, primitives, arrays, and plain objects, recursively.
 * Does not support Maps, Sets, Functions, or other non-JSON types.
 */
export declare function jsonDeepEquals(a: unknown, b: unknown): boolean;
//# sourceMappingURL=deep_equals.d.ts.map