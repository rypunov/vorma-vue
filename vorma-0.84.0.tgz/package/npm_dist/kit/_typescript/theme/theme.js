// kit/_typescript/theme/theme.ts
import { getClientCookie, setClientCookie } from "vorma/kit/cookies";
var THEMES = {
  Dark: "dark",
  Light: "light",
  System: "system"
};
var THEME_VALUES = Object.values(THEMES);
var THEME_KEY = "kit_theme";
var RESOLVED_THEME_KEY = "kit_resolved_theme";
var PREFERS_DARK_QUERY = window.matchMedia("(prefers-color-scheme: dark)");
var CLASSLIST = window.document.documentElement.classList;
var THEME_CHANGE_EVENT_KEY = "theme_change";
var bc = __newBC();
__setBCOnMessage(bc);
window.addEventListener("pagehide", () => bc.close());
window.addEventListener("pageshow", () => {
  bc = __newBC();
  __setBCOnMessage(bc);
});
function __newBC() {
  return new BroadcastChannel("kit_theme_channel");
}
function __setBCOnMessage(bc2) {
  bc2.onmessage = (e) => {
    const detail = e.data;
    const theme = detail.theme;
    const resolvedTheme = __getResolvedThemeFromTheme(theme);
    __setClassesAndDispatchEvent({ theme, resolvedTheme });
  };
}
PREFERS_DARK_QUERY.addEventListener("change", () => {
  if (CLASSLIST.contains(THEMES.System)) {
    setTheme(THEMES.System);
  }
});
function getTheme() {
  const theme = getClientCookie(THEME_KEY);
  return __isTheme(theme) ? theme : THEMES.System;
}
function getThemeLocal() {
  const theme = localStorage.getItem(THEME_KEY);
  return __isTheme(theme) ? theme : THEMES.System;
}
function getResolvedTheme() {
  const resolvedTheme = getClientCookie(RESOLVED_THEME_KEY);
  return __isResolvedTheme(resolvedTheme) ? resolvedTheme : THEMES.Light;
}
function getResolvedThemeLocal() {
  const resolvedTheme = localStorage.getItem(RESOLVED_THEME_KEY);
  return __isResolvedTheme(resolvedTheme) ? resolvedTheme : THEMES.Light;
}
function setTheme(theme) {
  const resolvedTheme = __getResolvedThemeFromTheme(theme);
  setClientCookie(THEME_KEY, theme);
  setClientCookie(RESOLVED_THEME_KEY, resolvedTheme);
  const detail = { theme, resolvedTheme };
  __setClassesAndDispatchEvent(detail);
  bc.postMessage(detail);
}
function setThemeLocal(theme) {
  const resolvedTheme = __getResolvedThemeFromTheme(theme);
  localStorage.setItem(THEME_KEY, theme);
  localStorage.setItem(RESOLVED_THEME_KEY, resolvedTheme);
  const detail = { theme, resolvedTheme };
  __setClassesAndDispatchEvent(detail);
  bc.postMessage(detail);
}
function addThemeChangeListener(listener) {
  window.addEventListener(THEME_CHANGE_EVENT_KEY, listener);
  return () => {
    window.removeEventListener(
      THEME_CHANGE_EVENT_KEY,
      listener
    );
  };
}
function initLocal() {
  const theme = localStorage.getItem(THEME_KEY) || THEMES.System;
  const resolvedTheme = __getResolvedThemeFromTheme(
    __isTheme(theme) ? theme : THEMES.System
  );
  CLASSLIST.add(theme);
  if (theme === THEMES.System) {
    CLASSLIST.add(resolvedTheme);
  }
  localStorage.setItem(THEME_KEY, theme);
  localStorage.setItem(RESOLVED_THEME_KEY, resolvedTheme);
}
function getNextToggleValue(theme) {
  switch (theme) {
    case THEMES.System:
      return THEMES.Light;
    case THEMES.Light:
      return THEMES.Dark;
    case THEMES.Dark:
      return THEMES.System;
  }
}
function __getResolvedThemeFromTheme(theme) {
  let resolvedTheme = theme;
  if (resolvedTheme === THEMES.System) {
    resolvedTheme = PREFERS_DARK_QUERY.matches ? THEMES.Dark : THEMES.Light;
  }
  return resolvedTheme;
}
function __setClassesAndDispatchEvent(detail) {
  CLASSLIST.remove(...THEME_VALUES);
  CLASSLIST.add(detail.theme);
  if (detail.theme === THEMES.System) {
    CLASSLIST.add(detail.resolvedTheme);
  }
  window.dispatchEvent(new CustomEvent(THEME_CHANGE_EVENT_KEY, { detail }));
}
function __isTheme(theme) {
  return THEME_VALUES.includes(theme);
}
function __isResolvedTheme(theme) {
  return theme === THEMES.Dark || theme === THEMES.Light;
}
export {
  THEMES,
  addThemeChangeListener,
  getNextToggleValue,
  getResolvedTheme,
  getResolvedThemeLocal,
  getTheme,
  getThemeLocal,
  initLocal,
  setTheme,
  setThemeLocal
};
//# sourceMappingURL=theme.js.map
