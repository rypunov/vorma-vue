export declare const THEMES: {
    readonly Dark: "dark";
    readonly Light: "light";
    readonly System: "system";
};
declare const THEME_VALUES: ("dark" | "light" | "system")[];
export type Theme = (typeof THEME_VALUES)[number];
export type ResolvedTheme = Exclude<Theme, typeof THEMES.System>;
type ThemeChangeEventDetail = {
    theme: Theme;
    resolvedTheme: ResolvedTheme;
};
export declare function getTheme(): Theme;
export declare function getThemeLocal(): Theme;
export declare function getResolvedTheme(): ResolvedTheme;
export declare function getResolvedThemeLocal(): ResolvedTheme;
export declare function setTheme(theme: Theme): void;
export declare function setThemeLocal(theme: Theme): void;
export declare function addThemeChangeListener(listener: (e: CustomEvent<ThemeChangeEventDetail>) => void): CleanupFunction;
type CleanupFunction = () => void;
export declare function initLocal(): void;
export declare function getNextToggleValue(theme: Theme): Theme;
export {};
//# sourceMappingURL=theme.d.ts.map