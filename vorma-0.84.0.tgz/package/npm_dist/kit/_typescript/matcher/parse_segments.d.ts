export declare function parseSegments(path: string): string[];
//# sourceMappingURL=parse_segments.d.ts.map