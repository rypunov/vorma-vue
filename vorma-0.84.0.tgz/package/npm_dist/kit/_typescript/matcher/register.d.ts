export type Params = Record<string, string>;
export type SegType = "splat" | "static" | "dynamic" | "index";
export type Segment = {
    normalizedVal: string;
    segType: SegType;
};
export type RegisteredPattern = {
    originalPattern: string;
    normalizedPattern: string;
    normalizedSegments: Segment[];
    lastSegType: SegType;
    lastSegIsNonRootSplat: boolean;
    lastSegIsIndex: boolean;
    numberOfDynamicParamSegs: number;
};
export type SegmentNode = {
    pattern: string;
    nodeType: number;
    children: Map<string, SegmentNode> | null;
    dynChildren: SegmentNode[];
    paramName: string;
    finalScore: number;
};
export type RegistrationOptions = {
    dynamicParamPrefixRune?: string;
    splatSegmentRune?: string;
    explicitIndexSegment?: string;
};
export type PatternRegistry = {
    staticPatterns: Map<string, RegisteredPattern>;
    dynamicPatterns: Map<string, RegisteredPattern>;
    rootNode: SegmentNode;
    config: {
        dynamicParamPrefixRune: string;
        splatSegmentRune: string;
        explicitIndexSegment: string;
        slashIndexSegment: string;
        usingExplicitIndexSegment: boolean;
    };
};
export declare const NODE_STATIC = 0;
export declare const NODE_DYNAMIC = 1;
export declare const NODE_SPLAT = 2;
export declare const SCORE_STATIC_MATCH = 2;
export declare const SCORE_DYNAMIC = 1;
export declare const SEG_TYPES: {
    splat: SegType;
    static: SegType;
    dynamic: SegType;
    index: SegType;
};
export declare function createPatternRegistry(opts?: RegistrationOptions): PatternRegistry;
export declare function registerPattern(registry: PatternRegistry, originalPattern: string): RegisteredPattern;
//# sourceMappingURL=register.d.ts.map