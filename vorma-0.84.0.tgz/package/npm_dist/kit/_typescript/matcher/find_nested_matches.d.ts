import type { Params, PatternRegistry, RegisteredPattern } from "./register.ts";
export type Match = {
    registeredPattern: RegisteredPattern;
    params: Params;
    splatValues: string[];
};
type FindNestedMatchesResult = {
    params: Params;
    splatValues: string[];
    matches: Match[];
};
export declare function findNestedMatches(registry: PatternRegistry, realPath: string): FindNestedMatchesResult | null;
export {};
//# sourceMappingURL=find_nested_matches.d.ts.map