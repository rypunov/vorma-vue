import { type Params, type PatternRegistry, type RegisteredPattern } from "./register.ts";
type BestMatch = {
    registeredPattern: RegisteredPattern;
    params: Params;
    splatValues: string[];
    score: number;
};
export declare function findBestMatch(registry: PatternRegistry, realPath: string): BestMatch | null;
export {};
//# sourceMappingURL=find_best_match.d.ts.map