export declare function getCSRFToken(opts: {
    isDev: boolean;
    cookieName?: string;
}): string | undefined;
//# sourceMappingURL=csrf.d.ts.map