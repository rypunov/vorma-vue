// kit/_typescript/csrf/csrf.ts
import { getClientCookie } from "vorma/kit/cookies";
function getCSRFToken(opts) {
  const prefix = opts.isDev ? "__Dev-" : "__Host-";
  const name = opts.cookieName || "csrf_token";
  return getClientCookie(prefix + name);
}
export {
  getCSRFToken
};
//# sourceMappingURL=csrf.js.map
