type Fn = (...args: Array<any>) => any;
export declare function debounce<T extends Fn>(fn: T, delayInMs: number): (...args: Parameters<T>) => Promise<Awaited<ReturnType<T>>>;
export {};
//# sourceMappingURL=debounce.d.ts.map