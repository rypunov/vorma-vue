// kit/_typescript/debounce/debounce.ts
function debounce(fn, delayInMs) {
  let timeoutID;
  return (...args) => {
    return new Promise((resolve) => {
      clearTimeout(timeoutID);
      timeoutID = window.setTimeout(() => {
        resolve(fn(...args));
      }, delayInMs);
    });
  };
}
export {
  debounce
};
//# sourceMappingURL=debounce.js.map
