// kit/_typescript/fmt/fmt.ts
function prettyJSON(obj) {
  return JSON.stringify(obj, null, 2);
}
export {
  prettyJSON
};
//# sourceMappingURL=fmt.js.map
