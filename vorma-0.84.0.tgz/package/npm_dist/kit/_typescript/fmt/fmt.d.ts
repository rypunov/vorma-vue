export declare function prettyJSON(obj: any): string;
//# sourceMappingURL=fmt.d.ts.map