import { type ExtractApp, type PermissivePatternBasedProps, type VormaAppBase, type VormaAppConfig, type VormaLoaderPattern } from "../vorma_app_helpers/vorma_app_helpers.ts";
type TypedNavigateOptions<App extends VormaAppBase, Pattern extends VormaLoaderPattern<App>> = PermissivePatternBasedProps<App, Pattern> & {
    replace?: boolean;
    scrollToTop?: boolean;
    search?: string;
    hash?: string;
    state?: unknown;
};
export declare function makeTypedNavigate<C extends VormaAppConfig>(vormaAppConfig: C): <Pattern extends VormaLoaderPattern<ExtractApp<C>>>(options: TypedNavigateOptions<ExtractApp<C>, Pattern>) => Promise<void>;
export {};
//# sourceMappingURL=typed_navigate.d.ts.map