export type VormaLinkPropsBase<LinkOnClickCallback> = {
    href?: string;
    prefetch?: "intent";
    prefetchDelayMs?: number;
    beforeBegin?: LinkOnClickCallback;
    beforeRender?: LinkOnClickCallback;
    afterRender?: LinkOnClickCallback;
    scrollToTop?: boolean;
    replace?: boolean;
    state?: unknown;
};
export declare function __makeFinalLinkProps<LinkOnClickCallback>(props: VormaLinkPropsBase<LinkOnClickCallback>, keys?: {
    onPointerEnter: string;
    onFocus: string;
    onPointerLeave: string;
    onBlur: string;
    onTouchCancel: string;
    onClick: string;
}): {
    dataExternal: true | undefined;
    onPointerEnter: (e: any) => void;
    onFocus: (e: any) => void;
    onPointerLeave: (e: any) => void;
    onBlur: (e: any) => void;
    onTouchCancel: (e: any) => void;
    onClick: (e: any) => Promise<void>;
};
//# sourceMappingURL=link_components.d.ts.map