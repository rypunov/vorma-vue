import type { VormaAppConfig } from "./vorma_app_helpers/vorma_app_helpers.ts";
import { type RouteErrorComponent } from "./vorma_ctx/vorma_ctx.ts";
export declare function initClient(options: {
    vormaAppConfig: VormaAppConfig;
    renderFn: () => void;
    defaultErrorBoundary?: RouteErrorComponent;
    useViewTransitions?: boolean;
}): Promise<void>;
//# sourceMappingURL=init_client.d.ts.map