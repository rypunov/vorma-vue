import type { RouteErrorComponent } from "./vorma_ctx/vorma_ctx.ts";
export declare const defaultErrorBoundary: RouteErrorComponent;
//# sourceMappingURL=error_boundary.d.ts.map