import type { VormaNavigationType } from "./client.ts";
import type { ScrollState } from "./scroll_state_manager.ts";
import { type GetRouteDataOutput } from "./vorma_ctx/vorma_ctx.ts";
type RerenderAppProps = {
    json: GetRouteDataOutput;
    navigationType: VormaNavigationType;
    runHistoryOptions?: {
        href: string;
        scrollStateToRestore?: ScrollState;
        replace?: boolean;
        scrollToTop?: boolean;
        state?: unknown;
    };
    onFinish: () => void;
};
export declare function __reRenderApp(props: RerenderAppProps): Promise<void>;
export {};
//# sourceMappingURL=rendering.d.ts.map