export declare const VORMA_HARD_RELOAD_QUERY_PARAM = "vorma_reload";
//# sourceMappingURL=hard_reload.d.ts.map