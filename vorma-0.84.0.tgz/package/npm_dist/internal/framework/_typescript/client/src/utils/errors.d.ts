export declare function isAbortError(error: unknown): boolean;
export declare function panic(msg?: string): never;
//# sourceMappingURL=errors.d.ts.map