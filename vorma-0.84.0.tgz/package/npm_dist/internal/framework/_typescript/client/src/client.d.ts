import { type ClientLoadersResult } from "./client_loaders.ts";
import { type StatusEventDetail } from "./events.ts";
import type { historyInstance } from "./history/npm_history_types.ts";
import { type RedirectData } from "./redirects/redirects.ts";
import { type ScrollState } from "./scroll_state_manager.ts";
import { type GetRouteDataOutput } from "./vorma_ctx/vorma_ctx.ts";
export type VormaNavigationType = "browserHistory" | "userNavigation" | "revalidation" | "redirect" | "prefetch" | "action";
export type NavigateProps = {
    href: string;
    state?: unknown;
    navigationType: VormaNavigationType;
    scrollStateToRestore?: ScrollState;
    replace?: boolean;
    redirectCount?: number;
    scrollToTop?: boolean;
};
type NavigationResult = ({
    response: Response;
    props: NavigateProps;
} & ({
    json: GetRouteDataOutput;
    cssBundlePromises: Array<Promise<any>>;
    waitFnPromise: Promise<ClientLoadersResult> | undefined;
} | {
    redirectData: RedirectData;
})) | undefined;
export type NavigationControl = {
    abortController: AbortController | undefined;
    promise: Promise<NavigationResult>;
};
type NavigationPhase = "fetching" | "waiting" | "rendering" | "complete";
type NavigationIntent = "none" | "navigate" | "revalidate";
interface NavigationEntry {
    control: NavigationControl;
    type: VormaNavigationType;
    intent: NavigationIntent;
    phase: NavigationPhase;
    startTime: number;
    targetUrl: string;
    originUrl: string;
    scrollToTop?: boolean;
    replace?: boolean;
    state?: unknown;
}
declare class NavigationStateManager {
    private _navigations;
    private _submissions;
    private lastDispatchedStatus;
    private dispatchStatusEventDebounced;
    private readonly REVALIDATION_COALESCE_MS;
    constructor();
    navigate(props: NavigateProps): Promise<{
        didNavigate: boolean;
    }>;
    beginNavigation(props: NavigateProps): NavigationControl;
    private beginUserNavigation;
    private beginPrefetch;
    private beginRevalidation;
    private createNavigation;
    private upgradeNavigation;
    private transitionPhase;
    private canSkipServerFetch;
    private fetchRouteData;
    private processNavigationResult;
    submit<T = any>(url: string | URL, requestInit?: RequestInit, options?: SubmitOptions): Promise<{
        success: true;
        data: T;
    } | {
        success: false;
        error: string;
    }>;
    private setNavigation;
    private deleteNavigation;
    removeNavigation(key: string): void;
    getNavigation(key: string): NavigationEntry | undefined;
    hasNavigation(key: string): boolean;
    getNavigationsSize(): number;
    getNavigations(): Map<string, NavigationEntry>;
    private abortAllNavigationsExcept;
    getStatus(): StatusEventDetail;
    clearAll(): void;
    private scheduleStatusUpdate;
    private dispatchStatusEvent;
}
export declare const navigationStateManager: NavigationStateManager;
export declare function vormaNavigate(href: string, options?: {
    replace?: boolean;
    scrollToTop?: boolean;
    search?: string;
    hash?: string;
    state?: unknown;
}): Promise<void>;
export declare function getLastTriggeredNavOrRevalidateTimestampMS(): number;
export declare function revalidate(): Promise<void>;
export type SubmitOptions = {
    dedupeKey?: string;
    revalidate?: boolean;
    skipGlobalLoadingIndicator?: boolean;
};
export declare function submit<T = any>(url: string | URL, requestInit?: RequestInit, options?: SubmitOptions): Promise<{
    success: true;
    data: T;
} | {
    success: false;
    error: string;
}>;
export declare function beginNavigation(props: NavigateProps): NavigationControl;
export declare function getStatus(): StatusEventDetail;
export declare function getLocation(): {
    pathname: string;
    search: string;
    hash: string;
    state: unknown;
};
export declare function getBuildID(): string;
export declare function getRootEl(): HTMLDivElement;
export declare function getHistoryInstance(): historyInstance;
export {};
//# sourceMappingURL=client.d.ts.map