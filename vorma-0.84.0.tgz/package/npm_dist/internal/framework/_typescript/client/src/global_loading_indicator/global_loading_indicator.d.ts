type GlobalLoadingIndicatorIncludesOption = "navigations" | "submissions" | "revalidations";
type GlobalLoadingIndicatorConfig = {
    start: () => void;
    stop: () => void;
    isRunning: () => boolean;
    include?: "all" | Array<GlobalLoadingIndicatorIncludesOption>;
    startDelayMS?: number;
    stopDelayMS?: number;
};
export declare function setupGlobalLoadingIndicator(config: GlobalLoadingIndicatorConfig): () => void;
export {};
//# sourceMappingURL=global_loading_indicator.d.ts.map