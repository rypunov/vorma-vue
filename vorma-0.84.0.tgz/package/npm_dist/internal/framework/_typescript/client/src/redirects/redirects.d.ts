import { type HrefDetails } from "vorma/kit/url";
import { type NavigateProps } from "../client.ts";
export type RedirectData = {
    href: string;
    hrefDetails: HrefDetails;
} & ({
    status: "did";
} | {
    status: "should";
    shouldRedirectStrategy: "hard" | "soft";
    latestBuildID: string;
});
export declare function getBuildIDFromResponse(response: Response | undefined): string;
export declare function parseFetchResponseForRedirectData(reqInit: RequestInit, res: Response): RedirectData | null;
export declare function effectuateRedirectDataResult(redirectData: RedirectData, redirectCount: number, originalProps?: NavigateProps): Promise<RedirectData | null>;
export declare function handleRedirects(props: {
    abortController: AbortController;
    url: URL;
    requestInit?: RequestInit;
    isPrefetch?: boolean;
    redirectCount?: number;
}): Promise<{
    redirectData: RedirectData | null;
    response?: Response;
}>;
//# sourceMappingURL=redirects.d.ts.map