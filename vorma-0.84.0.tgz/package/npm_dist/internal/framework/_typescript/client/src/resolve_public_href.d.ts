export declare function resolvePublicHref(relativeHref: string): string;
//# sourceMappingURL=resolve_public_href.d.ts.map