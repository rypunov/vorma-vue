type LinkOnClickCallback<E extends Event> = (event: E) => void | Promise<void>;
type LinkOnClickCallbacks<E extends Event> = {
    beforeBegin?: LinkOnClickCallback<E>;
    beforeRender?: LinkOnClickCallback<E>;
    afterRender?: LinkOnClickCallback<E>;
};
type GetPrefetchHandlersInput<E extends Event> = LinkOnClickCallbacks<E> & {
    href: string;
    delayMs?: number;
    scrollToTop?: boolean;
    replace?: boolean;
    search?: string;
    hash?: string;
    state?: unknown;
};
export declare function __getPrefetchHandlers<E extends Event>(input: GetPrefetchHandlersInput<E>): {
    start: (e: E) => void;
    stop: () => void;
    onClick: (e: E) => Promise<void>;
    url: URL;
    isHTTP: true;
    absoluteURL: string;
    relativeURL: string;
    isExternal: boolean;
    isInternal: boolean;
} | undefined;
export declare function __makeLinkOnClickFn<E extends Event>(callbacks: LinkOnClickCallbacks<E> & {
    scrollToTop?: boolean;
    replace?: boolean;
    state?: unknown;
}): (e: E) => Promise<void>;
export {};
//# sourceMappingURL=links.d.ts.map