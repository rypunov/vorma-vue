import type { ScrollState } from "./scroll_state_manager.ts";
export declare const VORMA_ROUTE_CHANGE_EVENT_KEY = "vorma:route-change";
export type RouteChangeEvent = CustomEvent<RouteChangeEventDetail>;
export type RouteChangeEventDetail = {
    __scrollState?: ScrollState;
};
export declare const addRouteChangeListener: (listener: (event: CustomEvent<RouteChangeEventDetail>) => void) => () => void;
export declare function dispatchRouteChangeEvent(detail: RouteChangeEventDetail): void;
export type StatusEvent = CustomEvent<StatusEventDetail>;
export type StatusEventDetail = {
    isNavigating: boolean;
    isSubmitting: boolean;
    isRevalidating: boolean;
};
export declare function dispatchStatusEvent(detail: StatusEventDetail): void;
export declare const addStatusListener: (listener: (event: CustomEvent<StatusEventDetail>) => void) => () => void;
type BuildIDEventDetail = {
    oldID: string;
    newID: string;
};
export declare function dispatchBuildIDEvent(detail: BuildIDEventDetail): void;
export declare const addBuildIDListener: (listener: (event: CustomEvent<BuildIDEventDetail>) => void) => () => void;
export declare function dispatchLocationEvent(): void;
export declare const addLocationListener: (listener: (event: CustomEvent<void>) => void) => () => void;
export {};
//# sourceMappingURL=events.d.ts.map