export declare function getEffectiveErrorData(): {
    index: number | undefined;
    error: string | undefined;
};
export declare class ComponentLoader {
    static loadComponents(importURLs: string[]): Promise<Map<string, any>>;
    static handleComponents(importURLs: string[]): Promise<void>;
    static handleErrorBoundaryComponent(importURLs: string[]): Promise<void>;
}
//# sourceMappingURL=component_loader.d.ts.map