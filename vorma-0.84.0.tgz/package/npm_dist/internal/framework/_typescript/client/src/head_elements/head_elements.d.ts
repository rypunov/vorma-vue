import type { HeadEl } from "../vorma_ctx/vorma_ctx.ts";
export declare function getStartAndEndComments(type: "meta" | "rest"): {
    startComment: Comment | null;
    endComment: Comment | null;
};
export declare function updateHeadEls(type: "meta" | "rest", blocks: Array<HeadEl>): void;
//# sourceMappingURL=head_elements.d.ts.map