export declare let __runClientLoadersAfterHMRUpdate: (importMeta: ImportMeta, pattern: string) => void;
export declare function initHMR(): void;
//# sourceMappingURL=hmr.d.ts.map