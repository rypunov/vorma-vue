import type { PatternRegistry } from "vorma/kit/matcher/register";
import type { VormaAppConfig } from "../vorma_app_helpers/vorma_app_helpers.ts";
export type HeadEl = {
    tag?: string;
    attributesKnownSafe?: Record<string, string>;
    booleanAttributes?: Array<string>;
    dangerousInnerHTML?: string;
};
type Meta = {
    title: HeadEl | null | undefined;
    metaHeadEls: Array<HeadEl> | null | undefined;
    restHeadEls: Array<HeadEl> | null | undefined;
};
type shared = {
    outermostServerError?: string;
    outermostClientError?: string;
    outermostServerErrorIdx?: number;
    outermostClientErrorIdx?: number;
    outermostError?: string;
    outermostErrorIdx?: number;
    matchedPatterns: Array<string>;
    loadersData: Array<any>;
    importURLs: Array<string>;
    exportKeys: Array<string>;
    errorExportKeys: string[];
    hasRootData: boolean;
    params: Record<string, string>;
    splatValues: Array<string>;
    buildID: string;
    activeComponents: Array<any> | null;
    activeErrorBoundary?: any;
};
export type GetRouteDataOutput = Omit<shared, "buildID"> & Meta & {
    deps: Array<string>;
    cssBundles: Array<string>;
};
export declare const VORMA_SYMBOL: unique symbol;
export type RouteErrorComponent = (props: {
    error: string;
}) => any;
export type ClientLoaderAwaitedServerData<RD, LD> = {
    matchedPatterns: string[];
    loaderData: LD;
    rootData: RD;
    buildID: string;
};
export type VormaClientGlobal = shared & {
    isDev: boolean;
    viteDevURL: string;
    publicPathPrefix: string;
    isTouchDevice: boolean;
    patternToWaitFnMap: Record<string, (props: {
        params: Record<string, string>;
        splatValues: string[];
        serverDataPromise: Promise<ClientLoaderAwaitedServerData<any, any>>;
        signal: AbortSignal;
    }) => Promise<any>>;
    clientLoadersData: Array<any>;
    defaultErrorBoundary: RouteErrorComponent;
    useViewTransitions: boolean;
    deploymentID: string;
    vormaAppConfig: VormaAppConfig;
    routeManifestURL: string;
    routeManifest: Record<string, number> | undefined;
    clientModuleMap: Record<string, {
        importURL: string;
        exportKey: string;
        errorExportKey: string;
    }>;
    patternRegistry: PatternRegistry;
};
export declare function __getVormaClientGlobal(): {
    get: <K extends keyof VormaClientGlobal>(key: K) => VormaClientGlobal[K];
    set: <K extends keyof VormaClientGlobal, V extends VormaClientGlobal[K]>(key: K, value: V) => void;
};
export declare const __vormaClientGlobal: {
    get: <K extends keyof VormaClientGlobal>(key: K) => VormaClientGlobal[K];
    set: <K extends keyof VormaClientGlobal, V extends VormaClientGlobal[K]>(key: K, value: V) => void;
};
export declare function getRouterData<T = any, P extends Record<string, string> = Record<string, string>>(): {
    buildID: string;
    matchedPatterns: string[];
    splatValues: string[];
    params: P;
    rootData: T;
};
export {};
//# sourceMappingURL=vorma_ctx.d.ts.map