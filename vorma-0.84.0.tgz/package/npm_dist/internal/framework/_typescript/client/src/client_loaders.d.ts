import { type GetRouteDataOutput } from "./vorma_ctx/vorma_ctx.ts";
export declare function setClientLoadersState(clr: ClientLoadersResult | undefined): void;
export declare function deriveAndSetErrorState(): void;
export declare function setupClientLoaders(): Promise<void>;
export declare function __registerClientLoaderPattern(pattern: string): Promise<void>;
export declare function findPartialMatchesOnClient(pathname: string): Promise<{
    params: import("vorma/kit/matcher/register").Params;
    splatValues: string[];
    matches: import("vorma/kit/matcher/find-nested").Match[];
} | null>;
type PartialWaitFnJSON = Pick<GetRouteDataOutput, "matchedPatterns" | "splatValues" | "params" | "hasRootData" | "loadersData" | "importURLs">;
export type ClientLoadersResult = {
    data: Array<any>;
    errorMessage?: string;
};
export declare function completeClientLoaders(json: PartialWaitFnJSON, buildID: string, runningLoaders: Map<string, Promise<any>>, signal: AbortSignal): Promise<ClientLoadersResult>;
export {};
//# sourceMappingURL=client_loaders.d.ts.map