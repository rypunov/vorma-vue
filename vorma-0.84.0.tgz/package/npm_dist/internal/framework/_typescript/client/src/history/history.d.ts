import { type Update as NPMHistoryUpdate } from "history";
import type { historyInstance } from "./npm_history_types.ts";
export declare class HistoryManager {
    private static instance;
    private static lastKnownLocation;
    static getInstance(): historyInstance;
    static getLastKnownLocation(): import("./npm_history_types.ts").historyLocation;
    static updateLastKnownLocation(location: typeof HistoryManager.instance.location): void;
    static init(): void;
    private static setManualScrollRestoration;
}
export declare function initCustomHistory(): void;
export declare function customHistoryListener({ action, location, }: NPMHistoryUpdate): Promise<void>;
//# sourceMappingURL=history.d.ts.map