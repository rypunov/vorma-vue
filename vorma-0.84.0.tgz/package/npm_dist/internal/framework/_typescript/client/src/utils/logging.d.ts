export declare function logInfo(message?: any, ...optionalParams: Array<any>): void;
export declare function logError(message?: any, ...optionalParams: Array<any>): void;
//# sourceMappingURL=logging.d.ts.map