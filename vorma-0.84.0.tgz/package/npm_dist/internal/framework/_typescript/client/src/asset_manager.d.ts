export declare class AssetManager {
    static preloadModule(url: string): void;
    static preloadCSS(url: string): Promise<void>;
    static applyCSS(bundles: string[]): void;
}
//# sourceMappingURL=asset_manager.d.ts.map