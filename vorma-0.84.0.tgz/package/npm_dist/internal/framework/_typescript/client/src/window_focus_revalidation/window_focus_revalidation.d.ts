/**
 * If called, will setup listeners to revalidate the current route when
 * the window regains focus and at least `staleTimeMS` has passed since
 * the last revalidation. The `staleTimeMS` option defaults to 5,000
 * (5 seconds). Returns a cleanup function.
 */
export declare function revalidateOnWindowFocus(options?: {
    staleTimeMS?: number;
}): () => void;
//# sourceMappingURL=window_focus_revalidation.d.ts.map