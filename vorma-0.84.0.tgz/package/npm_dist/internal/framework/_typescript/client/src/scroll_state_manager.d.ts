export type ScrollState = {
    x: number;
    y: number;
} | {
    hash: string;
};
declare class ScrollStateManager {
    private readonly STORAGE_KEY;
    private readonly PAGE_REFRESH_KEY;
    private readonly MAX_ENTRIES;
    saveState(key: string, state: ScrollState): void;
    getState(key: string): ScrollState | undefined;
    savePageRefreshState(): void;
    restorePageRefreshState(): void;
    private getMap;
    private saveMap;
}
export declare const scrollStateManager: ScrollStateManager;
export declare function __applyScrollState(state?: ScrollState): void;
export declare function saveScrollState(): void;
export {};
//# sourceMappingURL=scroll_state_manager.d.ts.map