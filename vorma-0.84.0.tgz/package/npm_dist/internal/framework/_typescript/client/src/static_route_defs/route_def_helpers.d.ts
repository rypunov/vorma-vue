type ImportPromise = Promise<Record<string, any>>;
type Key<T extends ImportPromise> = keyof Awaited<T>;
/**
 * Registers a route with the given route pattern,
 * module import promise, component export key, and
 * optional error boundary export key. Only for use
 * in your centralized build-time route definitions
 * file.
 */
export declare function route<IP extends ImportPromise>(pattern: string, importPromise: IP, componentKey: Key<IP>, errorBoundaryKey?: Key<IP>): void;
export {};
//# sourceMappingURL=route_def_helpers.d.ts.map